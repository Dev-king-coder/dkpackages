# Package-dkconverter

This package helps you to convert decimal numbers to other numeral system representations.File named **"conv.py"** has all the functions that do so.
---

## Function-bina

It converts decimal number into binary number which is passed as an argument to this function.
---

## Function-octl

It converts decimal number into octal number which is passed as an argument to this function.
---

## Function-hexdcml

It converts decimal number into hexadecimal number which is passed as an argument to this function.
---